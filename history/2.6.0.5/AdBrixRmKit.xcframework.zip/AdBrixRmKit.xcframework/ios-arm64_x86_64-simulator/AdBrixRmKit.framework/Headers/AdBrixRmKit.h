//
//  Core.h
//  Core
//
//  Created by 구근우 on 2021/01/25.
//

#import <Foundation/Foundation.h>
#import <AdBrixRmKit/AdBrixPushServiceObjC.h>
#import <AdBrixRmKit/ObjcUtil.h>

//! Project version number for Core.
FOUNDATION_EXPORT double CoreVersionNumber;

//! Project version string for Core.
FOUNDATION_EXPORT const unsigned char CoreVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Core/PublicHeader.h>


